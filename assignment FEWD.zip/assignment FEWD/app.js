// Recipe Data Array - 8 diverse recipes with required properties
const recipes = [
    {
        id: 1,
        title: "Garlic Butter Pasta",
        time: 15,
        difficulty: "easy",
        description: "Simple 15-minute pasta with garlic, butter, and parmesan cheese.",
        category: "pasta"
    },
    {
        id: 2,
        title: "Chicken Caesar Salad",
        time: 20,
        difficulty: "easy",
        description: "Fresh romaine lettuce with grilled chicken, croutons, and creamy dressing.",
        category: "salad"
    },
    {
        id: 3,
        title: "Beef Stroganoff",
        time: 45,
        difficulty: "medium",
        description: "Tender beef strips in a creamy mushroom sauce served over egg noodles.",
        category: "main"
    },
    {
        id: 4,
        title: "Vegetable Curry",
        time: 30,
        difficulty: "medium",
        description: "Spiced mixed vegetables in a rich coconut curry sauce with basmati rice.",
        category: "curry"
    },
    {
        id: 5,
        title: "Lobster Thermidor",
        time: 75,
        difficulty: "hard",
        description: "Luxurious lobster baked in a creamy mustard and cheese sauce.",
        category: "seafood"
    },
    {
        id: 6,
        title: "Beef Wellington",
        time: 120,
        difficulty: "hard",
        description: "Filet mignon wrapped in mushroom duxelles and puff pastry.",
        category: "main"
    },
    {
        id: 7,
        title: "Caprese Skewers",
        time: 10,
        difficulty: "easy",
        description: "Fresh mozzarella, cherry tomatoes, and basil on skewers with balsamic glaze.",
        category: "appetizer"
    },
    {
        id: 8,
        title: "Duck Confit",
        time: 180,
        difficulty: "hard",
        description: "Duck legs slow-cooked in their own fat, served with crispy skin.",
        category: "poultry"
    }
];

// DOM Selection - Get the recipe container element
const recipeContainer = document.querySelector('#recipe-container');

// Create Recipe Card Function - Generates HTML for a single recipe card
const createRecipeCard = (recipe) => {
    return `
        <div class="recipe-card" data-id="${recipe.id}">
            <h3>${recipe.title}</h3>
            <div class="recipe-meta">
                <span>⏱️ ${recipe.time} min</span>
                <span class="difficulty ${recipe.difficulty}">${recipe.difficulty}</span>
            </div>
            <p>${recipe.description}</p>
        </div>
    `;
};

// Render Recipes Function - Renders array of recipes to DOM
const renderRecipes = (recipesToRender) => {
    const recipeHTML = recipesToRender
        .map(createRecipeCard)
        .join('');
    
    recipeContainer.innerHTML = recipeHTML;
};

// Initialize the App - Render all recipes when page loads
renderRecipes(recipes);
